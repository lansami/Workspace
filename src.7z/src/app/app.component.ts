import { Component,OnInit } from '@angular/core';
import {MirceaComponent} from './mircea/mircea.component'
import {hero} from './hero'
import {HeroService} from './hero.service'
import {RouterModule} from '@angular/router'
import {HeroesComponent} from './heroes.component'


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
 providers:[HeroService]
})

export class AppComponent implements OnInit {

  title = 'Tour of heroes';

  heroes: hero[];
  selectedHero : hero ;

  constructor(private heroService:HeroService){}

  onSelect(hero: hero) : void
  {
    this.selectedHero = hero;
  }
  
  ngOnInit():void{
    this.getHeroes();
  }

  getHeroes(): void{
    this.heroService.getHeroes().then(heroes => this.heroes = heroes);
  }

}




