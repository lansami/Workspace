export class hero{
    id: number;
    name: string;
}