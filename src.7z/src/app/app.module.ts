import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { RouterModule} from '@angular/router';
import { provideRoutes} from '@angular/router';

import { AppComponent } from './app.component';
import { MirceaComponent } from './mircea/mircea.component';
import {HeroesComponent} from './heroes.component';
import {HeroService} from './hero.service'

@NgModule({
  declarations: [MirceaComponent,
  HeroesComponent,
    AppComponent,
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,    
    RouterModule.forRoot([{path: 'heroes',component: HeroesComponent},
                            {path: 'app.component',component: AppComponent}])
  ],
  providers: [HeroService],
  bootstrap: [AppComponent]
})

export class AppModule { }
